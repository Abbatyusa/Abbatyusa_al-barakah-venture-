ABBATYUSA AL-BARKAH VENTURE — Website package

Files:
- index.html: responsive business website
- logo.png: supplied ABBATYUSA Drinks logo

Included:
- Green, white and gold styling with the logo
- POS, money-transfer and general business services
- Basic product enquiry cards
- WhatsApp ordering and contact
- Customer enquiry form that opens WhatsApp

Important limitations:
- The enquiry form is not a true account-registration system and does not save a customer database.
- This is not a payment gateway and does not process online payments.
- Product prices are not set because actual prices/stock were not provided.
- Verify the business name, phone number, product catalogue and prices before publishing.

Free publishing option using GitHub Pages:
1. Sign in at github.com and create a repository.
2. Upload both index.html and logo.png to the repository root.
3. Open Settings > Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
5. Wait for the public website address to appear in the Pages settings.

WhatsApp is configured for 08166573963 in Nigeria international format (+2348166573963).
