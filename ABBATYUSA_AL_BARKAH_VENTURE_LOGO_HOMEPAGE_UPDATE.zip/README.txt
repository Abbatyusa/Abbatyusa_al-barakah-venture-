ABBATYUSA AL-BARKAH VENTURE — LOGO & HOMEPAGE UPDATE

Files:
- index.html: improved responsive homepage with your business logo in the header and main section.
- logo.png: ABBATYUSA Drinks logo.

HOW TO UPDATE YOUR LIVE WEBSITE FROM ANDROID
1. Extract this ZIP using your phone's File Manager.
2. Open your GitHub repository.
3. Tap Add file > Upload files.
4. Select index.html and logo.png from the extracted folder.
5. Upload both to the repository root (not inside a folder).
6. If prompted, replace the old index.html.
7. Commit message: Improve homepage and add ABBATYUSA logo
8. Tap Commit changes, wait a few minutes, then refresh your website.

IMPORTANT:
- The logo filename must be exactly logo.png (lowercase).
- WhatsApp contact: +234 816 657 3963.
- This is a static website; it does not store customer data or process payments.
